export const companyData = {
  name: "JYOTI CONSTRUCTIONS",
  logo: "/logo.png",
  tagline: "Mechanical Engineer & Contractor",
  about: "JYOTI CONSTRUCTIONS is a progressive engineering organization known for maintaining high standards and a strong reputation in the industry. Established by Mr. Avinash Kumar, the company is supported by a team of self-motivated and highly qualified professionals dedicated to delivering quality engineering solutions.",
  mission: "Our vision, mission, and goals focus on continuous improvement in the quality of services and performance leading to complete client satisfaction.",
  contact: {
    address: "H. No. 5-6-137/2/A, Krishna Nagar, FCI Cross Road, Ramagundam, Dist. Peddapalli, Telangana – 505215",
    email: "jyoticonstructions2007@gmail.com",
    phones: ["+91 7204360518", "+91 6299827878"]
  },
  services: [
    {
      id: 1,
      title: "Mechanical Works",
      description: "Comprehensive execution of all types of industrial mechanical works with precision and safety.",
      icon: "Wrench"
    },
    {
      id: 2,
      title: "Structural Fabrication & Erection",
      description: "Expertise in boiler structures and heavy industrial structural fabrication and erection.",
      icon: "Building"
    },
    {
      id: 3,
      title: "Industrial Piping",
      description: "Power cycle piping and cooling water piping works for thermal power stations and industries.",
      icon: "Pipette" // Will map to a suitable Lucide icon
    },
    {
      id: 4,
      title: "Damper Gates (FGD)",
      description: "Specialized in the dismantling and erection of Damper Gates for Flue Gas Desulfurization (FGD) systems.",
      icon: "Settings"
    },
    {
      id: 5,
      title: "Mill Reject Handling Systems",
      description: "Complete end-to-end solutions including fabrication, erection, and commissioning of MRH systems.",
      icon: "Factory"
    }
  ],
  commitments: [
    "Quality Workmanship",
    "Timely Project Execution",
    "Industrial Safety Standards",
    "Customer Satisfaction"
  ],
  clients: [
    { name: "BHEL (PSWR) / TSTPP", location: "NTPC Ramagundam, Telangana" },
    { name: "H.V. Equipments Pvt. Ltd. / TSTPP", location: "NTPC Ramagundam, Telangana" },
    { name: "PES Engineers Pvt. Ltd. / SCCL", location: "Jaipur, Telangana" }
  ],
  financials: [
    { year: "FY 2022–2023", amount: "Rs. 54,05,929.00" },
    { year: "FY 2023–2024", amount: "Rs. 55,05,771.00" }
  ],
  statutory: {
    gst: "36BIDPK0101J1ZS",
    pan: "BIDPK0101J",
    esic: "52001142960000999",
    pf: "NZKRN2740566000",
    msme: "UDYAM-TS-23-0006059"
  },
  gallery: [
    {
      id: 1,
      url: "https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?auto=format&fit=crop&q=80&w=800",
      title: "Structural Framework"
    },
    {
      id: 2,
      url: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=800",
      title: "Industrial Welding"
    },
    {
      id: 3,
      url: "https://images.unsplash.com/photo-1536895058696-a69b1c7ba34d?auto=format&fit=crop&q=80&w=800",
      title: "Piping Works"
    },
    {
      id: 4,
      url: "https://images.unsplash.com/photo-1513828742140-ccaa28f3eda0?auto=format&fit=crop&q=80&w=800",
      title: "Heavy Equipment Erection"
    },
    {
      id: 5,
      url: "https://images.unsplash.com/photo-1565008447742-97f6f38c985c?auto=format&fit=crop&q=80&w=800",
      title: "Project Commissioning"
    },
    {
      id: 6,
      url: "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&q=80&w=800",
      title: "Safety Standards"
    }
  ],
  faqs: [
    {
      id: 1,
      question: "What regions do you provide your services in?",
      answer: "We are capable of executing projects anywhere in India as per required standards and specifications, with a significant track record in thermal power stations across Telangana."
    },
    {
      id: 2,
      question: "What are your safety standards and certifications?",
      answer: "We strictly adhere to industrial safety standards. We fulfill all statutory obligations, including Employees’ Provident Fund (EPF), Employees’ State Insurance (ESI), Workmen Compensation, and maintain active MSME registration."
    },
    {
      id: 3,
      question: "How do you handle project timelines and execution?",
      answer: "Timelines are established based on the project's scale and complexity. Our experienced workforce and engineering expertise enable us to undertake challenging projects efficiently, ensuring timely execution without compromising on quality workmanship."
    },
    {
      id: 4,
      question: "Do you handle end-to-end mechanical installations?",
      answer: "Yes, we provide complete, specialized solutions including the fabrication, erection, and commissioning of structural works, power cycle piping, and specialized systems like Mill Reject Handling."
    }
  ],
};
