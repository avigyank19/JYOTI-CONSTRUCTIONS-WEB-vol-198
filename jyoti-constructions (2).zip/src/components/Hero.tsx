import React from 'react';
import { motion } from 'motion/react';
import { companyData } from '../data';
import { ChevronRight, Settings, Wrench, ShieldCheck } from 'lucide-react';

export function Hero() {
  return (
    <section id="home" className="relative h-screen min-h-[600px] flex items-center pt-20 overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <motion.img 
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 10, ease: "easeOut" }}
          src="https://images.unsplash.com/photo-1541888087525-4ebdacec7d11?auto=format&fit=crop&q=80&w=2000" 
          alt="Industrial Construction" 
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-slate-900/80 mix-blend-multiply"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full" style={{ perspective: "1000px" }}>
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 50, rotateX: 25, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }}
            transition={{ duration: 0.8, type: "spring", bounce: 0.3 }}
            style={{ transformStyle: "preserve-3d" }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-sm font-medium mb-6" style={{ transform: "translateZ(20px)" }}>
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
              ISO Certified Quality Standards
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-white leading-tight mb-6 tracking-tight" style={{ transform: "translateZ(40px)" }}>
              Precision <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-amber-600">Engineering</span> & Construction.
            </h1>
            
            <p className="text-lg sm:text-xl text-slate-300 mb-8 max-w-2xl leading-relaxed" style={{ transform: "translateZ(30px)" }}>
              We are a premier growing organization engaged in specialized mechanical works, serving thermal power stations and major industrial sectors across India.
            </p>
            
            <div className="flex flex-wrap gap-4" style={{ transform: "translateZ(20px)" }}>
              <a 
                href="#contact" 
                className="inline-flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-900 px-8 py-4 rounded-md font-bold transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-500/20"
              >
                Get in Touch <ChevronRight className="w-5 h-5" />
              </a>
              <a 
                href="#services" 
                className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white border border-white/10 px-8 py-4 rounded-md font-medium transition-all backdrop-blur-sm hover:-translate-y-1 hover:shadow-xl"
              >
                Our Services
              </a>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 30, rotateX: -20 }}
            animate={{ opacity: 1, y: 0, rotateX: 0 }}
            transition={{ duration: 0.8, delay: 0.4, type: "spring" }}
            style={{ transformStyle: "preserve-3d" }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-16 pt-8 border-t border-slate-700/50"
          >
            {[
              { icon: Settings, title: "Expert Team", subtitle: "Qualified professionals" },
              { icon: Wrench, title: "Specialized", subtitle: "Mechanical & Erection" },
              { icon: ShieldCheck, title: "Safety First", subtitle: "Strict industrial standards" }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                whileHover={{ scale: 1.05, translateZ: 20 }}
                className="flex items-center gap-4 cursor-pointer"
              >
                <div className="w-12 h-12 bg-slate-800 rounded-lg flex items-center justify-center text-amber-500 border border-slate-700 shadow-lg">
                  <feature.icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">{feature.title}</h3>
                  <p className="text-slate-400 text-sm">{feature.subtitle}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
