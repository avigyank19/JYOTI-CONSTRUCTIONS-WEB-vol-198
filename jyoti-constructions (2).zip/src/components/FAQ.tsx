import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { companyData } from '../data';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { TiltCard } from './TiltCard';

export function FAQ() {
  const [activeIndex, setActiveIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-24 bg-slate-900 text-white relative overflow-hidden">
      {/* Decorative background elements to match the dark theme sections */}
      <div className="absolute top-0 right-0 w-full h-px bg-gradient-to-l from-transparent via-amber-500/50 to-transparent opacity-30"></div>
      <div className="absolute top-40 right-10 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" style={{ perspective: "1000px" }}>
        
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30, rotateX: 15 }}
          whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, type: "spring" }}
          style={{ transformStyle: "preserve-3d" }}
        >
          <div 
            className="inline-flex items-center gap-2 mb-4 px-3 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-full text-sm font-semibold tracking-wide uppercase"
            style={{ transform: "translateZ(20px)" }}
          >
            <HelpCircle className="w-4 h-4" /> Frequently Asked Questions
          </div>
          <h2 
            className="text-3xl md:text-5xl font-bold mb-4"
            style={{ transform: "translateZ(40px)" }}
          >
            Got Questions? We Have Answers.
          </h2>
          <p 
            className="text-lg text-slate-400"
            style={{ transform: "translateZ(20px)" }}
          >
            Everything you need to know about our capabilities, safety standards, and service timelines.
          </p>
        </motion.div>

        <div className="space-y-4">
          {companyData.faqs.map((faq, index) => {
            const isOpen = activeIndex === index;
            
            return (
              <motion.div
                key={faq.id}
                initial={{ opacity: 0, y: 20, rotateX: -10 }}
                whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1, type: "spring" }}
              >
                <div 
                  className={`border border-slate-700/50 rounded-2xl overflow-hidden transition-colors duration-300 ${isOpen ? 'bg-slate-800' : 'bg-slate-800/40 hover:bg-slate-800/60'}`}
                >
                  <button
                    onClick={() => toggleAccordion(index)}
                    className="w-full px-6 py-5 flex items-center justify-between gap-4 text-left focus:outline-none"
                  >
                    <span className={`text-lg font-bold transition-colors ${isOpen ? 'text-amber-400' : 'text-slate-200'}`}>
                      {faq.question}
                    </span>
                    <motion.div
                      animate={{ rotate: isOpen ? 180 : 0 }}
                      transition={{ duration: 0.3, type: "spring", stiffness: 200 }}
                      className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-colors ${isOpen ? 'bg-amber-500/20 text-amber-500' : 'bg-slate-700 text-slate-400'}`}
                    >
                      <ChevronDown className="w-5 h-5" />
                    </motion.div>
                  </button>
                  
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: "easeInOut" }}
                      >
                        <div className="px-6 pb-6 pt-2 text-slate-400 leading-relaxed border-t border-slate-700/50 mt-2">
                          <p>{faq.answer}</p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
