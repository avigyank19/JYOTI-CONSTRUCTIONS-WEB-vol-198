import React from 'react';
import { motion } from 'motion/react';
import { companyData } from '../data';
import { Building, ShieldCheck, MapPin } from 'lucide-react';
import { TiltCard } from './TiltCard';

export function StatsAndClients() {
  return (
    <section id="clients" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Clients Section */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Our Valuable Clients</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Trusted by industry leaders to deliver critical mechanical and structural projects.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" style={{ perspective: "1000px" }}>
            {companyData.clients.map((client, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                whileInView={{ opacity: 1, scale: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <TiltCard>
                  <div 
                    className="bg-slate-50 border border-slate-200 p-8 rounded-xl text-center shadow-lg hover:shadow-2xl transition-shadow h-full flex flex-col justify-center"
                    style={{ transform: "translateZ(20px)", transformStyle: "preserve-3d" }}
                  >
                    <div 
                      className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner"
                      style={{ transform: "translateZ(30px)" }}
                    >
                      <Building className="w-8 h-8" />
                    </div>
                    <h3 
                      className="font-bold text-slate-900 mb-3 text-lg"
                      style={{ transform: "translateZ(20px)" }}
                    >
                      {client.name}
                    </h3>
                    <div 
                      className="flex items-center justify-center text-slate-500 text-sm gap-1"
                      style={{ transform: "translateZ(10px)" }}
                    >
                      <MapPin className="w-4 h-4 text-amber-500" />
                      <span>{client.location}</span>
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Financials */}
          <motion.div 
            initial={{ opacity: 0, y: 30, rotateX: 10 }}
            whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-slate-900 rounded-2xl p-8 sm:p-10 text-white shadow-2xl relative overflow-hidden group"
            style={{ transformStyle: "preserve-3d", perspective: "1000px" }}
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl group-hover:bg-amber-500/20 transition-colors duration-700"></div>
            <motion.h3 
              className="text-2xl font-bold mb-8 relative z-10"
              whileHover={{ translateZ: 20 }}
            >
              Financial Growth
            </motion.h3>
            <div className="space-y-6 relative z-10">
              {companyData.financials.map((fin, index) => (
                <motion.div 
                  key={index} 
                  className="flex justify-between items-center border-b border-slate-700 pb-4"
                  whileHover={{ scale: 1.02, x: 5 }}
                >
                  <span className="text-lg text-slate-300">{fin.year}</span>
                  <span className="text-2xl font-bold text-amber-400">{fin.amount}</span>
                </motion.div>
              ))}
            </div>
            <p className="mt-8 text-slate-400 text-sm leading-relaxed relative z-10">
              Jyoti Constructions continuously explores and strengthens its resources to achieve sustainable growth and long-term success.
            </p>
          </motion.div>

          {/* Statutory */}
          <motion.div 
            initial={{ opacity: 0, y: 30, rotateX: 10 }}
            whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="bg-slate-50 rounded-2xl p-8 sm:p-10 border border-slate-200 shadow-xl relative"
            style={{ transformStyle: "preserve-3d" }}
          >
            <motion.div 
              className="flex items-center gap-3 mb-8"
              whileHover={{ translateZ: 20 }}
            >
              <ShieldCheck className="w-8 h-8 text-amber-500" />
              <h3 className="text-2xl font-bold text-slate-900">Statutory Compliance</h3>
            </motion.div>
            
            <p className="text-slate-600 mb-6">
              All statutory obligations are duly fulfilled by our company, ensuring a secure and professional partnership.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
              <div className="bg-white p-4 rounded-lg border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">GST Number</span>
                <span className="text-slate-900 font-mono">{companyData.statutory.gst}</span>
              </div>
              <div className="bg-white p-4 rounded-lg border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">PAN Number</span>
                <span className="text-slate-900 font-mono">{companyData.statutory.pan}</span>
              </div>
              <div className="bg-white p-4 rounded-lg border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">ESIC Number</span>
                <span className="text-slate-900 font-mono">{companyData.statutory.esic}</span>
              </div>
              <div className="bg-white p-4 rounded-lg border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">PF Number</span>
                <span className="text-slate-900 font-mono">{companyData.statutory.pf}</span>
              </div>
              <div className="bg-white p-4 rounded-lg border border-slate-100 shadow-sm hover:shadow-md transition-shadow sm:col-span-2">
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">MSME Registration</span>
                <span className="text-slate-900 font-mono">{companyData.statutory.msme}</span>
              </div>
            </div>
          </motion.div>
        </div>

      </div>
    </section>
  );
}
