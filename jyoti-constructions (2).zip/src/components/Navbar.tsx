import React from 'react';
import { motion } from 'motion/react';
import { Menu, X, Phone, Mail } from 'lucide-react';
import { companyData } from '../data';

export function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);

  const links = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Clients', href: '#clients' },
    { name: 'FAQ', href: '#faq' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className="fixed w-full z-50 bg-slate-900/95 backdrop-blur-sm border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex-shrink-0 flex items-center gap-3">
            {companyData.logo ? (
              <img src={companyData.logo} alt="JC Logo" className="w-12 h-10 object-contain bg-white rounded-sm p-1" />
            ) : (
              <div className="w-10 h-10 bg-amber-500 rounded-sm flex items-center justify-center font-bold text-xl text-slate-900">
                JC
              </div>
            )}
            <div>
              <span className="font-bold text-xl tracking-wider block leading-none">JYOTI</span>
              <span className="text-xs text-slate-400 tracking-widest uppercase">Constructions</span>
            </div>
          </div>
          
          <div className="hidden md:flex space-x-8 items-center">
            {links.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                className="text-sm font-medium text-slate-300 hover:text-amber-500 transition-colors"
              >
                {link.name}
              </a>
            ))}
            <div className="flex items-center gap-4 ml-4 pl-4 border-l border-slate-700">
              <a href={`tel:${companyData.contact.phones[0]}`} className="flex items-center gap-2 text-sm text-slate-300 hover:text-amber-500 transition-colors">
                <Phone className="w-4 h-4" />
                <span className="hidden lg:inline">{companyData.contact.phones[0]}</span>
              </a>
            </div>
          </div>

          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-300 hover:text-white"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-slate-800 border-b border-slate-700"
        >
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {links.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block px-3 py-2 text-base font-medium text-slate-300 hover:text-amber-500 hover:bg-slate-700 rounded-md"
              >
                {link.name}
              </a>
            ))}
          </div>
        </motion.div>
      )}
    </nav>
  );
}
