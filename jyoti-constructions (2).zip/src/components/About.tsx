import React from 'react';
import { motion } from 'motion/react';
import { companyData } from '../data';
import { CheckCircle2, Factory, TrendingUp } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-24 bg-slate-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -40, rotateY: 15 }}
            whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, type: "spring" }}
            style={{ transformStyle: "preserve-3d", perspective: "1000px" }}
          >
            <div className="inline-block mb-4 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm font-semibold tracking-wide uppercase">
              About Our Company
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">
              Building the backbone of industrial infrastructure.
            </h2>
            <div className="space-y-4 text-slate-600 text-lg">
              <p>{companyData.about}</p>
              <p>{companyData.mission}</p>
            </div>

            <div className="mt-8 space-y-4">
              {companyData.commitments.map((commitment, index) => (
                <motion.div 
                  key={index} 
                  whileHover={{ x: 10, scale: 1.02 }}
                  className="flex items-center gap-3 p-2 -ml-2 rounded-lg hover:bg-white transition-colors cursor-pointer"
                >
                  <CheckCircle2 className="w-6 h-6 text-amber-500 flex-shrink-0" />
                  <span className="text-slate-700 font-medium">{commitment}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40, rotateY: -15 }}
            whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, type: "spring" }}
            className="relative"
            style={{ perspective: "1000px" }}
          >
            <motion.div 
              className="relative rounded-2xl overflow-hidden shadow-2xl"
              style={{ transformStyle: "preserve-3d" }}
              whileHover={{ rotateY: -5, rotateX: 5, scale: 1.02 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&q=80&w=1000" 
                alt="Engineering Team" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-slate-900/60 to-transparent"></div>
            </motion.div>
            
            {/* Overlay Stat Card - with continuous 3D floating animation */}
            <motion.div 
              animate={{ y: [-10, 10, -10], rotateX: [5, -5, 5], rotateY: [-5, 5, -5] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-8 -left-8 bg-white p-6 rounded-xl shadow-2xl border border-slate-100 max-w-xs hidden sm:block"
              style={{ transformStyle: "preserve-3d" }}
            >
              <div className="flex items-center gap-4 mb-2" style={{ transform: "translateZ(20px)" }}>
                <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center text-blue-600 shadow-inner">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900">Consistent Growth</div>
                </div>
              </div>
              <p className="text-sm text-slate-500" style={{ transform: "translateZ(10px)" }}>Delivering successful projects across India with a growing financial turnover year by year.</p>
            </motion.div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
