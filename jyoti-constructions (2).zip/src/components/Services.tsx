import React from 'react';
import { motion } from 'motion/react';
import { companyData } from '../data';
import { Wrench, Building2, Droplet, Settings2, Factory } from 'lucide-react';
import { TiltCard } from './TiltCard';

const iconMap: Record<string, React.ReactNode> = {
  Wrench: <Wrench className="w-8 h-8" />,
  Building: <Building2 className="w-8 h-8" />,
  Pipette: <Droplet className="w-8 h-8" />,
  Settings: <Settings2 className="w-8 h-8" />,
  Factory: <Factory className="w-8 h-8" />
};

export function Services() {
  return (
    <section id="services" className="py-24 bg-slate-900 text-white relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-amber-500/50 to-transparent opacity-30"></div>
      <div className="absolute -left-40 top-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
      <div className="absolute -right-40 bottom-20 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block mb-4 px-3 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-full text-sm font-semibold tracking-wide uppercase">
            Specialized Activities
          </div>
          <motion.h2 
            initial={{ opacity: 0, rotateX: 30, y: 20 }}
            whileInView={{ opacity: 1, rotateX: 0, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-5xl font-bold mb-6"
            style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
          >
            Our Engineering Services
          </motion.h2>
          <p className="text-lg text-slate-400">
            We offer comprehensive solutions tailored to the needs of thermal power stations and heavy industrial sectors.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" style={{ perspective: "1200px" }}>
          {companyData.services.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 40, rotateX: -20 }}
              whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: index * 0.1, type: "spring" }}
            >
              <TiltCard className="h-full">
                <div 
                  className="bg-slate-800/50 border border-slate-700/50 p-8 rounded-2xl hover:bg-slate-800 transition-colors group h-full flex flex-col shadow-2xl relative overflow-hidden"
                  style={{ transform: "translateZ(20px)", transformStyle: "preserve-3d" }}
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-amber-500/10 to-transparent rounded-bl-full transform translate-x-16 -translate-y-16 group-hover:translate-x-0 group-hover:translate-y-0 transition-transform duration-500"></div>
                  
                  <div 
                    className="w-16 h-16 bg-slate-900 rounded-xl flex items-center justify-center text-amber-500 mb-6 shadow-xl border border-slate-700 transition-all duration-500 group-hover:bg-amber-500 group-hover:text-slate-900 group-hover:shadow-amber-500/20"
                    style={{ transform: "translateZ(40px)" }}
                  >
                    {iconMap[service.icon] || <Wrench className="w-8 h-8" />}
                  </div>
                  <h3 
                    className="text-xl font-bold mb-4 text-white group-hover:text-amber-400 transition-colors"
                    style={{ transform: "translateZ(30px)" }}
                  >
                    {service.title}
                  </h3>
                  <p 
                    className="text-slate-400 leading-relaxed"
                    style={{ transform: "translateZ(10px)" }}
                  >
                    {service.description}
                  </p>
                </div>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
