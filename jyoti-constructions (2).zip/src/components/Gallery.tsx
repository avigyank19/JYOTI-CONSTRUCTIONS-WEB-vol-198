import React from 'react';
import { motion } from 'motion/react';
import { companyData } from '../data';
import { TiltCard } from './TiltCard';

export function Gallery() {
  return (
    <section id="gallery" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block mb-4 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm font-semibold tracking-wide uppercase">
            Project Gallery
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Our Work in Action</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            A glimpse into our execution capabilities, safety standards, and project scale across different sites.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8" style={{ perspective: "1000px" }}>
          {companyData.gallery.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.9, rotateX: 15 }}
              whileInView={{ opacity: 1, scale: 1, rotateX: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1, type: "spring" }}
            >
              <TiltCard>
                <div 
                  className="group relative rounded-xl overflow-hidden aspect-[4/3] bg-slate-200 shadow-xl cursor-pointer border border-slate-200"
                  style={{ transform: "translateZ(20px)", transformStyle: "preserve-3d" }}
                >
                  <img 
                    src={item.url} 
                    alt={item.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                    <h3 
                      className="text-white font-bold text-xl translate-y-4 group-hover:translate-y-0 transition-transform duration-300 shadow-sm"
                      style={{ transform: "translateZ(40px)" }}
                    >
                      {item.title}
                    </h3>
                    <div 
                      className="w-12 h-1 bg-amber-500 mt-3 transform origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-500 delay-100 shadow-md"
                      style={{ transform: "translateZ(30px)" }}
                    ></div>
                  </div>
                </div>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
