import React, { useEffect, useState } from 'react';
import { initAuth, googleSignIn, logout, getAccessToken } from '../lib/auth';
import { User } from 'firebase/auth';
import { Mail, LogOut, Send, Inbox, RefreshCw, Trash2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface EmailMessage {
  id: string;
  threadId: string;
  snippet: string;
  subject: string;
  from: string;
  date: string;
}

export function MailClient() {
  const [needsAuth, setNeedsAuth] = useState(true);
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  
  const [emails, setEmails] = useState<EmailMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  
  const [composeOpen, setComposeOpen] = useState(false);
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    const unsubscribe = initAuth(
      (user, t) => {
        setUser(user);
        setToken(t);
        setNeedsAuth(false);
      },
      () => {
        setNeedsAuth(true);
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!needsAuth && token && isOpen) {
      fetchEmails();
    }
  }, [needsAuth, token, isOpen]);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const result = await googleSignIn();
      if (result) {
        setToken(result.accessToken);
        setUser(result.user);
        setNeedsAuth(false);
      }
    } catch (err) {
      console.error('Login failed:', err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    setNeedsAuth(true);
    setUser(null);
    setToken(null);
    setEmails([]);
  };

  const fetchEmails = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=5&q=in:inbox', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      
      if (data.messages && data.messages.length > 0) {
        const fullMessages = await Promise.all(
          data.messages.map(async (msg: any) => {
            const detailRes = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${msg.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`, {
              headers: { Authorization: `Bearer ${token}` }
            });
            const detail = await detailRes.json();
            
            const getHeader = (name: string) => {
              const header = detail.payload.headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase());
              return header ? header.value : 'Unknown';
            };

            return {
              id: detail.id,
              threadId: detail.threadId,
              snippet: detail.snippet,
              subject: getHeader('Subject'),
              from: getHeader('From'),
              date: getHeader('Date')
            };
          })
        );
        setEmails(fullMessages);
      } else {
        setEmails([]);
      }
    } catch (error) {
      console.error('Error fetching emails:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!token) return;
    const confirmed = window.confirm("Are you sure you want to move this email to trash?");
    if (!confirmed) return;

    try {
      await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}/trash`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchEmails();
    } catch (error) {
      console.error('Error deleting email:', error);
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    
    const confirmed = window.confirm(`Are you sure you want to send this email to ${to}?`);
    if (!confirmed) return;
    
    setSending(true);
    try {
      const message = [
        `To: ${to}`,
        `Subject: ${subject}`,
        '',
        body
      ].join('\n');
      
      const encodedMessage = btoa(message).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
      
      await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
        method: 'POST',
        headers: { 
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ raw: encodedMessage })
      });
      
      setComposeOpen(false);
      setTo('');
      setSubject('');
      setBody('');
      alert("Email sent successfully!");
    } catch (error) {
      console.error('Error sending email:', error);
      alert("Failed to send email.");
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-amber-500 text-slate-900 rounded-full shadow-2xl flex items-center justify-center hover:bg-amber-400 transition-colors z-50 hover:scale-110 active:scale-95"
      >
        <Mail className="w-6 h-6" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-24 right-6 w-96 bg-white rounded-2xl shadow-2xl overflow-hidden z-50 border border-slate-200 flex flex-col max-h-[600px]"
          >
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold">Company Webmail</h3>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto bg-slate-50 relative p-4">
              {needsAuth ? (
                <div className="flex flex-col items-center justify-center h-full py-12 text-center space-y-6">
                  <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center text-blue-500 mb-2">
                    <Mail className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-lg">Admin Access</h4>
                    <p className="text-slate-500 text-sm mt-2 max-w-[250px] mx-auto">Sign in with Google to access the company webmail.</p>
                  </div>
                  
                  <button 
                    onClick={handleLogin}
                    disabled={isLoggingIn}
                    className="gsi-material-button w-full max-w-[240px] bg-white border border-slate-300 rounded shadow-sm hover:bg-slate-50 transition-colors flex items-center px-3 py-2 disabled:opacity-50"
                  >
                    <div className="w-6 h-6 mr-3">
                      <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="w-full h-full">
                        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                        <path fill="none" d="M0 0h48v48H0z"></path>
                      </svg>
                    </div>
                    <span className="text-slate-700 font-medium font-roboto text-sm">Sign in with Google</span>
                  </button>
                </div>
              ) : (
                <div className="flex flex-col h-full">
                  {!composeOpen ? (
                    <>
                      <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-200">
                        <div className="flex items-center gap-2 text-sm text-slate-600 font-medium">
                          <Inbox className="w-4 h-4" /> Inbox
                        </div>
                        <button onClick={fetchEmails} className="p-1 text-slate-400 hover:text-slate-800 transition-colors">
                          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                        </button>
                      </div>

                      <div className="space-y-3 mb-16">
                        {isLoading && emails.length === 0 ? (
                          <div className="text-center py-8 text-sm text-slate-500">Loading emails...</div>
                        ) : emails.length > 0 ? (
                          emails.map((email) => (
                            <div key={email.id} className="bg-white p-3 rounded-lg shadow-sm border border-slate-100 relative group">
                              <div className="flex justify-between items-start mb-1">
                                <span className="font-semibold text-slate-900 text-sm truncate pr-4">{email.from.split('<')[0]}</span>
                                <span className="text-xs text-slate-400 whitespace-nowrap">
                                  {new Date(email.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                                </span>
                              </div>
                              <h5 className="text-sm font-medium text-slate-700 truncate mb-1">{email.subject}</h5>
                              <p className="text-xs text-slate-500 line-clamp-2">{email.snippet}</p>
                              <button 
                                onClick={() => handleDelete(email.id)}
                                className="absolute top-2 right-2 p-1.5 bg-red-50 text-red-600 rounded-md opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-100"
                                title="Delete Email"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))
                        ) : (
                          <div className="text-center py-8 text-sm text-slate-500">No emails found.</div>
                        )}
                      </div>

                      <div className="absolute bottom-0 left-0 right-0 p-4 bg-white border-t border-slate-100 flex justify-between items-center">
                        <button 
                          onClick={handleLogout}
                          className="text-xs font-medium text-slate-500 hover:text-red-500 flex items-center gap-1 transition-colors"
                        >
                          <LogOut className="w-3.5 h-3.5" /> Sign out
                        </button>
                        <button 
                          onClick={() => setComposeOpen(true)}
                          className="bg-amber-500 hover:bg-amber-600 text-slate-900 text-sm font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition-colors shadow-sm"
                        >
                          <Send className="w-4 h-4" /> Compose
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col h-full bg-white -m-4 p-4 rounded-b-2xl border-t border-slate-100">
                      <div className="flex justify-between items-center mb-4">
                        <h4 className="font-bold text-slate-900">New Message</h4>
                        <button onClick={() => setComposeOpen(false)} className="text-slate-400 hover:text-slate-800">
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                      
                      <form onSubmit={handleSend} className="flex flex-col flex-1 gap-3">
                        <input 
                          type="email" 
                          placeholder="To" 
                          required
                          value={to}
                          onChange={(e) => setTo(e.target.value)}
                          className="w-full text-sm border-b border-slate-200 py-2 outline-none focus:border-amber-500 transition-colors"
                        />
                        <input 
                          type="text" 
                          placeholder="Subject" 
                          required
                          value={subject}
                          onChange={(e) => setSubject(e.target.value)}
                          className="w-full text-sm border-b border-slate-200 py-2 outline-none focus:border-amber-500 transition-colors"
                        />
                        <textarea 
                          placeholder="Compose email..." 
                          required
                          value={body}
                          onChange={(e) => setBody(e.target.value)}
                          className="w-full flex-1 text-sm py-2 outline-none resize-none min-h-[150px]"
                        />
                        
                        <div className="mt-auto pt-4 flex justify-end">
                          <button 
                            type="submit" 
                            disabled={sending}
                            className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold py-2 px-6 rounded-lg flex items-center gap-2 transition-colors disabled:opacity-70"
                          >
                            {sending ? 'Sending...' : <><Send className="w-4 h-4" /> Send</>}
                          </button>
                        </div>
                      </form>
                    </div>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
