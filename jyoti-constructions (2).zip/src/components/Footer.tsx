import React from 'react';
import { companyData } from '../data';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 text-slate-400 py-12 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-8">
          
          <div className="md:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              {companyData.logo ? (
                <img src={companyData.logo} alt="JC Logo" className="w-12 h-10 object-contain bg-white rounded-sm p-1" />
              ) : (
                <div className="w-10 h-10 bg-amber-500 rounded-sm flex items-center justify-center font-bold text-xl text-slate-900">
                  JC
                </div>
              )}
              <div>
                <span className="font-bold text-xl tracking-wider block leading-none text-white">JYOTI</span>
                <span className="text-xs text-slate-500 tracking-widest uppercase">Constructions</span>
              </div>
            </div>
            <p className="text-sm leading-relaxed max-w-xs">
              Delivering specialized mechanical engineering and construction solutions across India with a commitment to quality and safety.
            </p>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#home" className="hover:text-amber-500 transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-amber-500 transition-colors">About Us</a></li>
              <li><a href="#services" className="hover:text-amber-500 transition-colors">Services</a></li>
              <li><a href="#gallery" className="hover:text-amber-500 transition-colors">Project Gallery</a></li>
              <li><a href="#contact" className="hover:text-amber-500 transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Capabilities</h4>
            <ul className="space-y-3 text-sm">
              <li>Mechanical Works</li>
              <li>Structural Fabrication & Erection</li>
              <li>Power Cycle Piping</li>
              <li>FGD Damper Gates</li>
              <li>Mill Reject Handling Systems</li>
            </ul>
          </div>

        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
          <p>&copy; {currentYear} {companyData.name}. All rights reserved.</p>
          <div className="flex gap-4">
            <span>Udyam Reg: {companyData.statutory.msme}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
