import React from 'react';
import { motion } from 'motion/react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { StatsAndClients } from './components/StatsAndClients';
import { Gallery } from './components/Gallery';
import { FAQ } from './components/FAQ';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { MailClient } from './components/MailClient';

function SectionWrapper({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans selection:bg-amber-500 selection:text-slate-900 scroll-smooth">
      <Navbar />
      <main>
        <Hero />
        <SectionWrapper><About /></SectionWrapper>
        <SectionWrapper><Services /></SectionWrapper>
        <SectionWrapper><StatsAndClients /></SectionWrapper>
        <SectionWrapper><Gallery /></SectionWrapper>
        <SectionWrapper><FAQ /></SectionWrapper>
        <SectionWrapper><Contact /></SectionWrapper>
      </main>
      <Footer />
      <MailClient />
    </div>
  );
}


